import { useState, useEffect, useCallback, useRef } from 'react';

// ============================================================================
// HOOK PRINCIPAL: Gestión de Conversaciones con Chatwoot - OPTIMIZADO v2
// ============================================================================

interface ChatwootAPIConfig {
  baseUrl?: string;
}

const useChatwootAPI = (config: ChatwootAPIConfig = {}) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const apiCall = useCallback(async (endpoint: string, method = 'GET', data: any = null) => {
    setLoading(true);
    setError(null);

    try {
      const requestConfig: RequestInit = {
        method,
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || ''
        }
      };

      if (data && method !== 'GET') {
        requestConfig.body = JSON.stringify(data);
      }

      const response = await fetch(endpoint, requestConfig);

      if (!response.ok) {
        const errorData = await response.text();
        throw new Error(`API Error: ${response.status} - ${errorData}`);
      }

      const result = await response.json();
      return result;
    } catch (err: any) {
      setError(err.message);
      console.error('Chatwoot API Error:', err);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  return { apiCall, loading, error };
};

// ============================================================================
// HOOK: useConversations - Gestión completa con PAGINACIÓN y OPTIMIZACIONES
// ============================================================================

export const useConversations = () => {
  const [conversations, setConversations] = useState<any[]>([]);
  const [activeConversation, setActiveConversationState] = useState<any | null>(null);
  const [userInboxId, setUserInboxId] = useState<number | null>(null);
  const { apiCall, loading, error } = useChatwootAPI();
  
  // ✅ NUEVO: Estados de paginación
  const [currentPage, setCurrentPage] = useState(1);
  const [hasMorePages, setHasMorePages] = useState(true);
  const [totalConversations, setTotalConversations] = useState(0);
  const perPage = 25; // Cargar 25 conversaciones por página
  
  // ✅ NUEVO: Timestamps para polling incremental
  const lastFetchTimestamp = useRef<number>(Date.now());
  const lastUpdateTimestamp = useRef<number>(Date.now());
  
  // ✅ NUEVO: Cache de conversaciones para merge inteligente
  const conversationsCache = useRef<Map<number, any>>(new Map());
  
  // ✅ NUEVO: Ref para evitar stale closure en callbacks
  const conversationsRef = useRef<any[]>([]);
  const activeConversationRef = useRef<any | null>(null);
  
  // ✅ NUEVO: Flag para evitar cargas concurrentes de mensajes
  const isLoadingMessagesRef = useRef<Set<number>>(new Set());
  
  // Mantener refs actualizadas
  useEffect(() => {
    conversationsRef.current = conversations;
  }, [conversations]);
  
  useEffect(() => {
    activeConversationRef.current = activeConversation;
  }, [activeConversation]);

  // ========================================
  // Obtener inbox_id del usuario autenticado
  // ========================================
  useEffect(() => {
    const fetchUserInboxId = async () => {
      try {
        const result = await fetch('/api/user/profile', {
          credentials: 'include',
          headers: {
            'Accept': 'application/json',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || ''
          }
        });

        if (result.ok) {
          const data = await result.json();
          const inboxId = data.user?.company?.chatwoot_inbox_id || data.chatwoot_inbox_id || null;
          
          console.log('✅ User inbox_id obtenido:', inboxId);
          setUserInboxId(inboxId);
        }
      } catch (err) {
        console.error('Error obteniendo inbox_id del usuario:', err);
      }
    };

    fetchUserInboxId();
  }, []);

  // ========================================
  // ✅ OPTIMIZADO: Cargar TODAS las conversaciones (backend hace paginación infinita)
  // ========================================
  const fetchAllConversations = useCallback(async () => {
    try {
      console.log('📚 Cargando TODAS las conversaciones...');
      
      // El backend ahora devuelve TODAS las conversaciones automáticamente
      const result = await apiCall('/api/chatwoot-proxy/conversations', 'GET');

      const payload = result?.data?.payload || result?.payload || [];
      const meta = result?.data?.meta || result?.meta || {};
      
      if (Array.isArray(payload)) {
        const chatwootConversations = payload.map((conv: any) => ({
          id: conv.id,
          contact: {
            id: conv.meta?.sender?.id || conv.contact_id,
            name: conv.meta?.sender?.name || 'Usuario Anónimo',
            email: conv.meta?.sender?.email || 'sin-email@example.com',
            phone_number: conv.meta?.sender?.phone_number || conv.meta?.sender?.name,
            avatar: conv.meta?.sender?.name?.charAt(0).toUpperCase() || 'U',
            avatarUrl: conv.meta?.sender?.thumbnail || conv.meta?.sender?.avatar_url || null,
            status: conv.meta?.sender?.availability_status || 'offline'
          },
          last_message: {
            content: conv.last_non_activity_message?.content || 'Sin mensajes',
            timestamp: conv.last_activity_at || conv.created_at,
            sender: conv.last_non_activity_message?.message_type === 0 ? 'contact' : 'agent'
          },
          status: conv.status,
          priority: conv.priority || 'medium',
          labels: conv.labels || [],
          unread_count: conv.unread_count || 0,
          inbox_id: conv.inbox_id,
          account_id: conv.account_id,
          assignee_id: conv.assignee?.id || null,
          assignee: conv.assignee || null,
          updated_at: conv.last_activity_at || conv.updated_at
        }));
        
        setConversations(chatwootConversations);
        setTotalConversations(meta.total_count || chatwootConversations.length);
        setCurrentPage(1);
        setHasMorePages(false); // Ya cargamos todas
        
        console.log(`✅ Total conversaciones cargadas: ${chatwootConversations.length}`);
      } else {
        setConversations([]);
        setTotalConversations(0);
      }
      
    } catch (err) {
      console.error('❌ Error cargando todas las conversaciones:', err);
      setConversations([]);
    }
  }, [apiCall]);

  // ========================================
  // ✅ OPTIMIZADO: Fetch de conversaciones con paginación
  // ========================================
  const fetchConversations = useCallback(async (page: number = 1, append: boolean = false) => {
    try {
      console.log(`📄 Fetching conversations - Page ${page}, Per page: ${perPage}`);
      
      const result = await apiCall(
        `/api/chatwoot-proxy/conversations?page=${page}&per_page=${perPage}`,
        'GET'
      );

      const payload = result?.data?.payload || result?.payload || [];
      const meta = result?.data?.meta || result?.meta || {};
      
      // Actualizar metadatos de paginación
      setTotalConversations(meta.count || payload.length);
      setHasMorePages(meta.current_page < meta.total_pages);
      setCurrentPage(page);
      
      if (Array.isArray(payload)) {
        const chatwootConversations = payload.map((conv: any) => {
          const conversation = {
            id: conv.id,
            contact: {
              id: conv.meta?.sender?.id || conv.contact_id,
              name: conv.meta?.sender?.name || 'Usuario Anónimo',
              email: conv.meta?.sender?.email || 'sin-email@example.com',
              phone_number: conv.meta?.sender?.phone_number || conv.meta?.sender?.name,
              avatar: conv.meta?.sender?.name?.charAt(0).toUpperCase() || 'U',
            avatarUrl: conv.meta?.sender?.thumbnail || conv.meta?.sender?.avatar_url || null,
              status: conv.meta?.sender?.availability_status || 'offline'
            },
            last_message: {
              content: conv.last_non_activity_message?.content || 'Sin mensajes',
              timestamp: conv.last_activity_at || conv.created_at,
              sender: conv.last_non_activity_message?.message_type === 0 ? 'contact' : 'agent'
            },
            status: conv.status,
            priority: conv.priority || 'medium',
            labels: conv.labels || [],
            unread_count: conv.unread_count || 0,
            inbox_id: conv.inbox_id,
            account_id: conv.account_id,
            assignee_id: conv.assignee?.id || null,
            assignee: conv.assignee || null,
            updated_at: conv.last_activity_at || conv.updated_at
          };
          
          // Actualizar cache
          conversationsCache.current.set(conversation.id, conversation);
          
          return conversation;
        });

        if (append) {
          // Append para infinite scroll
          setConversations(prev => {
            const existingIds = new Set(prev.map(c => c.id));
            const newConversations = chatwootConversations.filter(c => !existingIds.has(c.id));
            return [...prev, ...newConversations];
          });
        } else {
          // Replace para refresh
          setConversations(chatwootConversations);
        }
        
        lastFetchTimestamp.current = Date.now();
        
        console.log(`✅ Loaded ${chatwootConversations.length} conversations (Page ${page})`);
      } else {
        setConversations([]);
      }
    } catch (err) {
      console.error('Error fetching conversations:', err);
      if (!append) {
        setConversations([]);
      }
    }
  }, [apiCall, perPage]);

  // ========================================
  // ✅ NUEVO: Polling incremental (solo conversaciones actualizadas)
  // ========================================
  const fetchUpdatedConversations = useCallback(async () => {
    try {
      const updatedSince = Math.floor(lastUpdateTimestamp.current / 1000);
      
      console.log(`🔄 Fetching updated conversations since ${new Date(lastUpdateTimestamp.current).toISOString()}`);
      
      const result = await apiCall(
        `/api/chatwoot-proxy/conversations?updated_since=${updatedSince}`,
        'GET'
      );

      const payload = result?.data?.payload || result?.payload || [];
      
      if (Array.isArray(payload) && payload.length > 0) {
        console.log(`✅ Found ${payload.length} updated conversations`);
        
        const updatedConversations = payload.map((conv: any) => ({
          id: conv.id,
          contact: {
            id: conv.meta?.sender?.id || conv.contact_id,
            name: conv.meta?.sender?.name || 'Usuario Anónimo',
            email: conv.meta?.sender?.email || 'sin-email@example.com',
            phone_number: conv.meta?.sender?.phone_number || conv.meta?.sender?.name,
            avatar: conv.meta?.sender?.name?.charAt(0).toUpperCase() || 'U',
            avatarUrl: conv.meta?.sender?.thumbnail || conv.meta?.sender?.avatar_url || null,
            status: conv.meta?.sender?.availability_status || 'offline'
          },
          last_message: {
            content: conv.last_non_activity_message?.content || 'Sin mensajes',
            timestamp: conv.last_activity_at || conv.created_at,
            sender: conv.last_non_activity_message?.message_type === 0 ? 'contact' : 'agent'
          },
          status: conv.status,
          priority: conv.priority || 'medium',
          labels: conv.labels || [],
          unread_count: conv.unread_count || 0,
          inbox_id: conv.inbox_id,
          account_id: conv.account_id,
          assignee_id: conv.assignee?.id || null,
          assignee: conv.assignee || null,
          updated_at: conv.last_activity_at || conv.updated_at
        }));
        
        // Merge inteligente: actualizar existentes o agregar nuevas
        setConversations(prev => {
          const conversationMap = new Map(prev.map(c => [c.id, c]));

          updatedConversations.forEach(updated => {
            const existing = conversationMap.get(updated.id);
            const merged = existing ? { ...updated, unread_count: Math.max(updated.unread_count || 0, existing.unread_count || 0) } : updated;
            conversationMap.set(updated.id, merged);
            conversationsCache.current.set(updated.id, merged);
          });

          // Helper function para obtener timestamp
          const getTimestamp = (conv: any) => {
            if (conv.updated_at) {
              return conv.updated_at > 10000000000 ? conv.updated_at : conv.updated_at * 1000;
            }
            if (conv.last_message?.timestamp) {
              return conv.last_message.timestamp > 10000000000 
                ? conv.last_message.timestamp 
                : conv.last_message.timestamp * 1000;
            }
            return 0;
          };

          // Ordenar por timestamp más reciente
          const sorted = Array.from(conversationMap.values()).sort((a, b) => {
            const timeA = getTimestamp(a);
            const timeB = getTimestamp(b);
            return timeB - timeA;
          });

          console.log(`🔄 Conversaciones reordenadas. Primera: ${sorted[0]?.contact.name} (ID: ${sorted[0]?.id}) - Timestamp: ${new Date(getTimestamp(sorted[0])).toISOString()}`);
          
          return sorted;
        });
        lastUpdateTimestamp.current = Date.now();
        
        return updatedConversations.length;
      } else {
        console.log('✅ No updates found');
        return 0;
      }
    } catch (err) {
      console.error('Error fetching updated conversations:', err);
      return 0;
    }
  }, [apiCall]);

  // ========================================
  // ✅ NUEVO: Cargar más conversaciones (infinite scroll)
  // ========================================
  const loadMoreConversations = useCallback(async () => {
    if (!hasMorePages || loading) return;
    
    const nextPage = currentPage + 1;
    await fetchConversations(nextPage, true);
  }, [currentPage, hasMorePages, loading, fetchConversations]);

  // ========================================
  // Enviar mensaje
  // ========================================
  const sendMessage = useCallback(async (conversationId: number, content: string) => {
    try {
      const messageData = {
        content,
        message_type: 'outgoing',
        private: false
      };

      const result = await apiCall(
        `/api/chatwoot-proxy/conversations/${conversationId}/messages`,
        'POST',
        messageData
      );

      if (result?.payload) {
        // ✅ NO agregar optimísticamente - dejar que llegue vía webhook/polling
        // Esto evita mensajes duplicados
        console.log('✅ Mensaje enviado exitosamente', { 
          id: result.payload.id, 
          content: result.payload.content 
        });

        return {
          id: result.payload.id,
          content: result.payload.content,
          timestamp: result.payload.created_at,
          sender: 'agent',
          status: 'sent'
        };
      }

      throw new Error('No se pudo enviar el mensaje');
    } catch (err) {
      console.error('Error enviando mensaje:', err);
      throw err;
    }
  }, [apiCall]);

  // ========================================
  // Cargar mensajes de conversación
  // ========================================
  const loadConversationMessages = useCallback(async (conversationId: number) => {
    // ✅ Evitar cargas concurrentes de la misma conversación
    if (isLoadingMessagesRef.current.has(conversationId)) {
      console.log(`⏭️ Ya se están cargando mensajes para conversación ${conversationId}, omitiendo...`);
      return;
    }
    
    isLoadingMessagesRef.current.add(conversationId);
    
    try {
      const result = await apiCall(`/api/chatwoot-proxy/conversations/${conversationId}/messages`);

      const messagesArray = result?.payload?.payload || result?.payload || [];

      if (Array.isArray(messagesArray)) {
        const chatwootMessages = messagesArray.map((msg: any) => ({
          id: msg.id,
          content: msg.content,
          timestamp: msg.created_at,
          sender: msg.message_type === 0 ? 'contact' : 'agent',
          status: msg.status || 'sent',
          attachments: msg.attachments || [],
          sender_name: msg.sender?.name || 'Usuario',
          isOptimistic: false // Mensajes del servidor NO son optimistas
        }));

        // ✅ Eliminar duplicados por ID (usar Map para mantener solo el último)
        const uniqueMessages = Array.from(
          new Map(chatwootMessages.map((msg: any) => [msg.id, msg])).values()
        );

        // Usar ref para evitar stale closure
        const conversation = conversationsRef.current.find((c: any) => c.id === conversationId);
        if (conversation) {
          setActiveConversationState({
            ...conversation,
            messages: uniqueMessages // ✅ Solo mensajes reales del servidor
          });

          // ✅ ARREGLADO: Marcar como leído INMEDIATAMENTE (visual instantáneo)
          // 1. Actualizar estado local primero para feedback visual instantáneo
          setConversations(prev =>
            prev.map(conv =>
              conv.id === conversationId ? { ...conv, unread_count: 0 } : conv
            )
          );

          // 2. Actualizar conversación activa
          setActiveConversationState(prev =>
            prev ? { ...prev, unread_count: 0 } : prev
          );

          // 3. Sincronizar con backend en segundo plano (sin bloquear UI)
          setTimeout(() => {
            markConversationAsRead(conversationId);
          }, 300);
        }
      }
    } catch (err) {
      console.error('Error cargando mensajes:', err);
      // Usar ref para evitar stale closure
      const conversation = conversationsRef.current.find((c: any) => c.id === conversationId);
      if (conversation) {
        setActiveConversationState({
          ...conversation,
          messages: []
        });
      }
    } finally {
      // ✅ Remover flag después de completar (con pequeño delay)
      setTimeout(() => {
        isLoadingMessagesRef.current.delete(conversationId);
      }, 500);
    }
  }, [apiCall]);

  // ========================================
  // Marcar conversación como leída
  // ========================================
  const markConversationAsRead = useCallback(async (conversationId: number) => {
    try {
      await apiCall(`/api/chatwoot-proxy/conversations/${conversationId}/update_last_seen`, 'POST');

      // Actualizar estado local
      setConversations(prev =>
        prev.map(conv =>
          conv.id === conversationId ? { ...conv, unread_count: 0 } : conv
        )
      );

      // Usar ref para evitar stale closure
      if (activeConversationRef.current?.id === conversationId) {
        setActiveConversationState(prev =>
          prev ? { ...prev, unread_count: 0 } : prev
        );
      }
    } catch (err) {
      console.error('Error marcando como leída:', err);
    }
  }, [apiCall]);

  // ========================================
  // ✅ NUEVO: Cargar TODAS las conversaciones inicialmente
  // ========================================
  useEffect(() => {
    fetchAllConversations();
  }, [fetchAllConversations]);

  return {
    conversations: conversations || [],
    activeConversation,
    userInboxId,
    loading,
    error,
    fetchConversations,
    fetchAllConversations, // ✅ NUEVO: Función para cargar TODAS las conversaciones
    fetchUpdatedConversations,
    loadMoreConversations,
    sendMessage,
    loadConversationMessages,
    setActiveConversation: setActiveConversationState,
    // ✅ NUEVO: Metadatos de paginación
    currentPage,
    hasMorePages,
    totalConversations,
    setConversations, //  NUEVO: Función para actualizar conversaciones directamente
    perPage
  };
};

// ============================================================================
// HOOK: useTeams - Gestión de equipos
// ============================================================================

export const useTeams = () => {
  const [teams, setTeams] = useState<any[]>([]);
  const { apiCall, loading, error } = useChatwootAPI();

  const fetchTeams = useCallback(async () => {
    try {
      const result = await apiCall('/api/chatwoot-proxy/teams');
      setTeams(result);
    } catch (err) {
      console.error('Error fetching teams:', err);
    }
  }, [apiCall]);

  const createTeam = useCallback(async (teamData: any) => {
    try {
      const result = await apiCall('/api/chatwoot-proxy/teams', 'POST', teamData);
      await fetchTeams();
      return result;
    } catch (err) {
      console.error('Error creating team:', err);
      throw err;
    }
  }, [apiCall, fetchTeams]);

  useEffect(() => {
    fetchTeams();
  }, [fetchTeams]);

  return { teams, loading, error, fetchTeams, createTeam };
};

// ============================================================================
// HOOK: useLabels - Gestión de etiquetas
// ============================================================================

export const useLabels = () => {
  const [labels, setLabels] = useState<any[]>([]);
  const { apiCall, loading, error } = useChatwootAPI();

  const fetchLabels = useCallback(async () => {
    try {
      const result = await apiCall('/api/chatwoot-proxy/labels');
      setLabels(result);
    } catch (err) {
      console.error('Error fetching labels:', err);
    }
  }, [apiCall]);

  const createLabel = useCallback(async (labelData: any) => {
    try {
      const result = await apiCall('/api/chatwoot-proxy/labels', 'POST', labelData);
      await fetchLabels();
      return result;
    } catch (err) {
      console.error('Error creating label:', err);
      throw err;
    }
  }, [apiCall, fetchLabels]);

  useEffect(() => {
    fetchLabels();
  }, [fetchLabels]);

  return { labels, loading, error, fetchLabels, createLabel };
};

// ============================================================================
// HOOK: useAgents - Gestión de agentes
// ============================================================================

export const useAgents = () => {
  const [agents, setAgents] = useState<any[]>([]);
  const { apiCall, loading, error } = useChatwootAPI();

  const fetchAgents = useCallback(async () => {
    try {
      const result = await apiCall('/api/chatwoot-proxy/agents');
      setAgents(result);
    } catch (err) {
      console.error('Error fetching agents:', err);
    }
  }, [apiCall]);

  const createAgent = useCallback(async (agentData: any) => {
    try {
      const result = await apiCall('/api/chatwoot-proxy/agents', 'POST', agentData);
      await fetchAgents();
      return result;
    } catch (err) {
      console.error('Error creating agent:', err);
      throw err;
    }
  }, [apiCall, fetchAgents]);

  useEffect(() => {
    fetchAgents();
  }, [fetchAgents]);

  return { agents, loading, error, fetchAgents, createAgent };
};

// ============================================================================
// HOOK: useEnterpriseDashboard - Dashboard empresarial
// ============================================================================

export const useEnterpriseDashboard = () => {
  const [dashboardData, setDashboardData] = useState<any>(null);
  const { apiCall, loading, error } = useChatwootAPI();

  const fetchDashboardData = useCallback(async () => {
    try {
      const result = await apiCall('/api/chatwoot-proxy/enterprise/dashboard');
      setDashboardData(result);
    } catch (err) {
      console.error('Error fetching dashboard data:', err);
    }
  }, [apiCall]);

  useEffect(() => {
    fetchDashboardData();
  }, [fetchDashboardData]);

  return { dashboardData, loading, error, fetchDashboardData };
};

// ============================================================================
// HOOK: useUserStats - Estadísticas de usuario
// ============================================================================

export const useUserStats = () => {
  const [stats, setStats] = useState<any>(null);
  const { apiCall, loading, error } = useChatwootAPI();

  const fetchUserStats = useCallback(async () => {
    try {
      const result = await apiCall('/api/chatwoot-proxy/user/stats');
      setStats(result);
    } catch (err) {
      console.error('Error fetching user stats:', err);
    }
  }, [apiCall]);

  useEffect(() => {
    fetchUserStats();
  }, [fetchUserStats]);

  return { stats, loading, error, fetchUserStats };
};
